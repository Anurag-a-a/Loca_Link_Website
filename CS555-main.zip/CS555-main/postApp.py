from flask import Flask, render_template, Blueprint, session
from flask import redirect
from flask import url_for
from flask import request
from model.community import *
from model.post import *
from model.user import *
from flask import jsonify

app = Flask(__name__)
post_blueprint = Blueprint('post', __name__)

#Lijuan
@post_blueprint.route("/create/<int:pk>", methods=["GET", 'POST'])
def createPost(pk):
    if request.method == 'POST':
        username = session.get("username")
        user_id = get_user_id_by_username(username)
        title=request.form.get("title")
        content=request.form.get("content")

        if exist_post(title):
            createPost_message = "Title has been used. "
            return render_template('home.html', message=createPost_message)
        else:
            add_post(user_id, pk, title, content)
            return redirect("/post/list/{}".format(pk))
    return render_template('createPost.html',communityId=pk)
#Lijuan
@post_blueprint.route("/list/<int:pk>", methods=["GET", 'POST'])
def PostList(pk):

    lst=get_postList(pk)
    username=session['username']
    return render_template("PostList.html",lst=lst,username=username,communityId=pk)
#Lijuan
@post_blueprint.route("/like/<int:pk>", methods=["GET", 'POST'])
def like(pk):
    add_like(pk)
    return jsonify({"code":200})
#Lijuan
@post_blueprint.route("/follow/<int:pk>", methods=["GET", 'POST'])
def follow(pk):
    username = session.get("username")
    user_id = get_user_id_by_username(username)
    if select_follow(pk,user_id)==0:
        add_follow(pk,user_id)
    else:
        del_follow(pk,user_id)

    return jsonify({"code":200})
