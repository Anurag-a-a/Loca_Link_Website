import pymysql

conn = pymysql.connect(host='localhost', user='root', password='rootroot', db='team20')

cur = conn.cursor()

#Lijuan
def add_post(userId, communityId, title, content):
    sql = "INSERT INTO post(userId,communityId,title,content) VALUES ('" + str(userId) + "','" + str(communityId) + "','" + title + "','" + content + "')"
    print(sql)
    conn.ping(reconnect=True)
    cur.execute(sql)
    conn.commit()
    conn.cursor()
    conn.close()


def exist_post(title):
    sql = "SELECT * FROM post WHERE title ='" + title + "'"
    conn.ping(reconnect=True)
    cur.execute(sql)
    result = cur.fetchall()
    conn.commit()
    if (len(result) == 0):
        return False
    else:
        return True
#Lijuan
def get_postList(community_id):
    sql = "SELECT id,title,content,likeNum,isTop,createTime FROM post where communityId={}".format(community_id)
    conn.ping(reconnect=True)
    cur.execute(sql)
    result = cur.fetchall()
    conn.commit()
    if result:
        return result
    else:
        return []
#Lijuan
def add_like(post_id):
    sql = "update post set likeNum=likeNum+1 where id={}".format(post_id)
    conn.ping(reconnect=True)
    cur.execute(sql)
    conn.commit()
    conn.cursor()
    conn.close()
#Lijuan
def add_follow(followerId,followedId):
    sql = "INSERT INTO follow(followerId,followedId) VALUES ('" + str(followerId) + "','" + str(followedId) + "')"
    conn.ping(reconnect=True)
    cur.execute(sql)
    conn.commit()
    conn.cursor()
    conn.close()
#Lijuan
def del_follow(followerId,followedId):
    sql = "delete follow where followerId={} and followedId={}".format(followerId,followedId)
    conn.ping(reconnect=True)
    cur.execute(sql)
    conn.commit()
    conn.cursor()
    conn.close()

#Lijuan
def select_follow(followerId,followedId):
    sql = "SELECT count(1) FROM follow where followerId={} and followedId={}".format(followerId,followedId)
    conn.ping(reconnect=True)
    cur.execute(sql)
    result = cur.fetchone()
    conn.commit()
    if result:
        return result[0]
    else:
        return 0

